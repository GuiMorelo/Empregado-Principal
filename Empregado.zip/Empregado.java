package com.mycompany.empregado;


public class Empregado {

    private String nome;
    private int idade;
    private double salario;
    
    public Empregado(String nome, int idade, double salario){
        
        this.nome = nome;
        this.idade = idade;
        this.salario = salario;
        
    }
    public String getNome(){
        return nome;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    public int getIdade(){
        return idade;
    }
    public void setIdade(int idade){
        this.idade = idade;
    }
    public double getSalario(){
        return salario;
    }
    public void setSalario(double salario){
        this.salario = salario;
    }
    
    @Override
    public String toString(){
       return "Empregado [Nome = " + nome + ", Idade = " + idade + ", Salario = R$ " + salario + "]";
    }
    
    public void promover(){
        if(idade >= 18){
            aumentarSalario(25);
        }
        else{
            System.out.println("A promoção só poderá ser realizada se o funcionário tiver mais de 18 anos!");
        }
    }
    public void aumentarSalario(double perc){
        salario += salario * perc/100; 
    }
    public void demitir(int escolha){
        switch(escolha){
            
            case 1:
                System.out.println("Justa Causa: o funcionário deverá cumprir aviso prévio!");
                break;
                
            case 2:
                System.out.println("Decisão do Empregado: O Empregado recebera uma multa de 40% no salário, o Salário sera: R$ "+ salario*0.40);
                break;
                
            case 3:
                System.out.println("Aposentadoria: O Salário de aposentadoria será calculado conforme a tabela do INSS!");
                
                if(salario >= 1000 && salario <= 2000){
                    salario = 1500;
                    System.out.println("O Salario e: R$ "+salario);
                }else if(salario > 2000 && salario <= 3000){
                    salario = 2500;
                    System.out.println("O salario e: R$ "+salario);
                }else if(salario > 3000 && salario <= 4000){
                    salario = 3500;
                    System.out.println("O Salario e: R$ "+salario);
                }else{
                    salario = 4000;
                    System.out.println("O Salario e: R$ "+salario);
                }
                break;      
        }
    }
    
    public void fazerAniversario(){
        idade++;
    }

}

