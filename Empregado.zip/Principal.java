package com.mycompany.empregado;

import java.util.ArrayList;
import java.util.Scanner;

public class Principal {

    private static ArrayList<Empregado> empreg = new ArrayList<>();
    private static Scanner leia = new Scanner(System.in);

    public static void main(String[] args) {
        int escolha = 0;
        while (escolha != 7) {
            mostrarMenu();
            try {
                escolha = Integer.parseInt(leia.nextLine());
                executarEscolha(escolha);
            } catch (NumberFormatException e) {
                System.out.println("Opção inválida! Por favor, insira um número.");
            }
        }
    }

    private static void mostrarMenu() {
        
        System.out.println("");
        System.out.println("            ---  MENU ---  ");
        System.out.println("");
        System.out.println("FACA SUA ESCOLHA DE ACORDO COM O NUMERO ABAIXO:");
        System.out.println("");
        System.out.println("1 - Criar novo empregado");
        System.out.println("2 - Promover empregado");
        System.out.println("3 - Aumentar salario do empregado");
        System.out.println("4 - Demitir empregado");
        System.out.println("5 - Fazer aniversario do empregado");
        System.out.println("6 - Mostrar detalhes dos empregados");
        System.out.println("");
        System.out.println("7 - SAIR");
        System.out.println("");
        
    }

    private static void executarEscolha(int escolha) {
        
        switch (escolha) {
            
            case 1 -> novoEmpregado();
            case 2 -> promoverEmpregado();
            case 3 -> aumentarSalario();
            case 4 -> demitirEmpregado();
            case 5 -> fazerAniversario();
            case 6 -> detalhesEmpregado();
            case 7 -> System.out.println("SENTIREMOS SUA FALTA, ATÉ MAIS!");
            default -> System.out.println("Opção inválida!!!");
            
        }
    }

    private static void novoEmpregado() {
        
        System.out.print("Nome: ");
        String nome = leia.nextLine();
        System.out.print("Salário: R$");
        double salario = Double.parseDouble(leia.nextLine());
        System.out.print("Idade: ");
        int idade = Integer.parseInt(leia.nextLine());
        Empregado novoEmpregado = new Empregado(nome, idade, salario);
        empreg.add(novoEmpregado);
        System.out.println("PROCESSO FINALIZADO, EMPREGADO CRIADO!");
        System.out.println("");
        
    }

    private static void promoverEmpregado() {
        
        Empregado empregado = selectEmpregado();
        
        if (empregado != null) {
            empregado.promover();
            System.out.println("PROCESSO FINALIZADO, EMPREGADO PROMOVIDO!");
            System.out.println("");
            
        }
    }

    private static void aumentarSalario() {
        
        Empregado empregado = selectEmpregado();
        
        if (empregado != null) {
            
            System.out.print("Digite o percentual de aumento: ");
            double perc = Double.parseDouble(leia.nextLine());
            empregado.aumentarSalario(perc);
            System.out.println("PROCESSO FINALIZADO, SALÁRIO AUMENTADO!");
            System.out.println("");
            
        }
    }

    private static void demitirEmpregado() {
        
        Empregado empregado = selectEmpregado();
        
        if (empregado != null) {
            
            System.out.println("ESCOLHA O MOTIVO:");
            System.out.println("");
            System.out.println("1 - JUSTA CAUSA.");
            System.out.println("2 - DECISÃO DO EMPREGADOR.");
            System.out.println("3 - APOSENTADORIA.");
            System.out.println("");
            int motivo = Integer.parseInt(leia.nextLine());
            empregado.demitir(motivo);
            
        }
    }

    private static void fazerAniversario() {
        
        Empregado empregado = selectEmpregado();
        
        if (empregado != null) {
            empregado.fazerAniversario();
            System.out.println("PROCESSO FINALIZADO, ANIVERSÁRIO FEITO!");
            System.out.println("");
            
        }
    }

    private static void detalhesEmpregado() {
        
        if (empreg.isEmpty()) {
            
            System.out.println("NÃO CONSTA NENHUM EMPREGADO NO SISTEMA!");
            System.out.println("");
            
        } else {
            
            for (Empregado empregado : empreg) {
                System.out.println(empregado);
                
            }
        }
    }

    private static Empregado selectEmpregado() {
        
        if (empreg.isEmpty()) {
            
            System.out.println("NÃO CONSTA NENHUM EMPREGADO NO SISTEMA!");
            System.out.println("");
            return null;
            
        }

        System.out.println("Selecione o EMPREGADO pelo índice:");
        System.out.println("");
        
        for (int i = 0; i < empreg.size(); i++) {
            
            System.out.println((i + 1) + ". " + empreg.get(i).getNome());
            
        }

        int num = Integer.parseInt(leia.nextLine());
        
        if (num < 1 || num > empreg.size()) {
            
            System.out.println("EMPREGADO INVÁLIDO!");
            System.out.println("");
            return null;
            
        }
        
        return empreg.get(num - 1);
        
    }
}
